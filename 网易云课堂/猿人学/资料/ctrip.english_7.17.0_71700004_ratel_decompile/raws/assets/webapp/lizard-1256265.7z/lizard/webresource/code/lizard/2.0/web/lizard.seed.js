/*
* Ctrip Lizard JavaScript Framework
* Copyright(C) 2008 - 2019, All rights reserved,ctrip.com.
* Date:2019-07-03 16:18:50
* tag:h-201907031618
*/
document.write("<script src='http://webresource.c-ctrip.com/code/lizard/2.0/web/lizard.seed.js'></script>");
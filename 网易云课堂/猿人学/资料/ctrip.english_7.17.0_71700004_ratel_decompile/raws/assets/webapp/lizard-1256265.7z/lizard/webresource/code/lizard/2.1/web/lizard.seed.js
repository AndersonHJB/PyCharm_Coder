/*
* Ctrip Lizard JavaScript Framework
* Copyright(C) 2008 - 2019, All rights reserved,ctrip.com.
* Date:2019-07-03 16:18:50
* tag:h-201907031618
*/
for(var scripts=document.getElementsByTagName("script")||[],reg=/lizard\.seed\.(src\.)*js.*$/gi,curPath="",i=0;i<scripts.length;i++){var src=scripts[i].getAttribute("src");if(src&&reg.test(src)){var filePath=src.replace(reg,"").replace("2.1","2.2");break}}document.write("<script src='"+filePath+"lizard.seed.js'></script>");
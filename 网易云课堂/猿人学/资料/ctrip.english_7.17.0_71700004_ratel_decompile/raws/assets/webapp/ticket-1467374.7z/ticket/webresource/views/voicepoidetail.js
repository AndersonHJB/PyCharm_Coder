define([
    'cPageView',
    'cHybridShell',
    'TicketCommon',
    'TicketModel',
    'cGuider',
    'cShell',
    'cPopLayer2',
    'BulkLazyLoad',
    'cMemberService',
    'CommonStore',
    'routerAdapter',
    'TicketStore',
    'cPopLayer',
    'cUtilHybrid',
    'TicketConfig',
    'voicePoiDetail',
    'TicketTraceLog',
    'cGuiderService',
    'i18_en_us',
    'i18_zh_hk',
    'TranslateKey'
], function (cPageView,
             cHybridShell,
             TicketCommon,
             TicketModel,
             cGuider,
             cShell,
             PopLayer2,
             BulkLazyLoad,
             cMemberService,
             CommonStore,
             routerAdapter,
             TicketStore,
             cPopLayer,
             cUtilHybrid,
             TicketConfig,
             voicePoiDetail,
             TicketTraceLog,
             cGuiderService, i18_en_us, i18_zh_hk,
             TranslateKey) {

    var i18n_100018464 = {
        'en-us': i18_en_us,
        'zh-hk': i18_zh_hk,
    };

    var isInApp = Lizard.isHybrid || Lizard.isInCtripApp,
        isIOS = !!navigator.userAgent.match(/iP(ad|hone|od).*\sos\s(\d)/i);
    var ticketVoiceDetailReqStore = TicketStore.TicketVoiceDetailReqStore.getInstance();
    var _base = {
        pageid: TicketCommon.pageid("voiceguide"),
        hpageid: TicketCommon.hpageid("voiceguide"),
        autoplay: false,
        onCreate: function () {
            this.els = {
                mainContainer: this.$el.find('#voicePoiDetailMainContent'),
            };
            this.instances = {
                VoiceDetailModel: TicketModel.VoiceDetailModel.getInstance(),
            };
        },
        onShow: function () {

            this.getNetworkType(this.initPage.bind(this))

        },
        onHide: function () {
            this.destroyVoicePoiDetail();
        },
    };
    var _ui = {};
    var _methods = {

        initPage: function (networkType) {
            var self = this;
            self.i18trans = i18_en_us;
            self.locale = 'en-US';
            this.hasNetwork = networkType !== 'NO';
            if (window.Internal) {
                window.Internal.callNative("Util", "getIBULocateInfo", null, 'getIBULocateInfo', function (res) {
                    var locale = (res.locale || '').replace('_', '-');
                    self.locale = locale;
                    self.i18trans = i18n_100018464[locale.toLowerCase()] || i18_en_us;
                    self.doAfterGetI18();
                })
            } else {
                this.doAfterGetI18();
            }

        },

        doAfterGetI18: function () {
            // 页面加载完处理loading遮盖问题
            if (Lizard.isHybrid) {
                CtripUtil.app_h5_page_finish_loading()
            }
            TicketCommon.historyManager.setCurrentNodeByName('voicepoidetail');
            var text = this.getTransValueByKey('key.page.voicedetail.loading2') || '加载中';
            this.showLoading({
                datamodel: {
                    content: text + '...'
                }
            });
            this.setHeader();
            this.fetchVoiceDetail();
        },

        initVoicePoiDetail: function () {
            var self = this;
            this.header.set({
                navBarStyle: 'white'
            });
            document.querySelector('body').classList.add('nofastclick');

            var clientHeight = window.innerHeight || document.documentElement.clientHeight;
            TicketCommon.hideHeader();
            isInApp && isIOS && this.els.mainContainer.addClass('body_ios_hybrid');
            if (isIOS) {
                this.els.mainContainer.addClass('ios_ui')
            } else {
                this.els.mainContainer.addClass('android_ui')
            }
            this.els.mainContainer.html(_.template(Lizard.T('entryTpl')));

            //options:数据、元素、PageView方法
            var options = {
                el: this.$el.find('#voice-container'),
                data: {
                    voicePoiDetail: this._datas || {},
                    voicePoiList: [],
                    realClientHeight: clientHeight
                },
                handles: {
                    traceLog: TicketTraceLog.getInstance(),
                },
                getNetworkType: this.getNetworkType.bind(this),
                getPageId: this.getPageId.bind(this),
                hasNetwork: this.hasNetwork,
                i18trans: self.i18trans,
                getTransValueByKey: this.getTransValueByKey.bind(this),
                stringProcess: this.stringProcess.bind(this),
                locale: this.locale
            };

            !this.voicePoiDetail && (this.voicePoiDetail = new voicePoiDetail(options));
        },
        handleBack: function () {
            if (isInApp) {
                cGuider.backToLastPage();
            } else {
                TicketCommon.h5Back();
            }
        },

        getPageId: function () {
            return Lizard.isHybrid ? this.hpageid : this.pageid;
        },

        getTransValueByKey: function (key) {
            return this.i18trans[key] || '';
        },

        stringProcess: function () {
            if (!arguments.length) {
                return '';
            }
            var args = Array.prototype.slice.call(arguments);
            var string = args[0];
            var rest = args.slice(1, args.length);
            for (var i = 0; i < rest.length; i++) {
                let index = string.indexOf('{' + i + '}');
                if (index > -1) {
                    string = string.split('');
                    string.splice(index, 2 + i.toString().length, rest[i]);
                    string = string.join('');
                }
            }
            return string
        },

        fetchVoiceDetail: function () {
            var self = this;
            this.instances.VoiceDetailModel.setParam({
                pageid: this.getPageId(),
                resourceid: Number(Lizard.P('optionid')),
                ver: '8.3.2.1',
                locale: self.locale,
                currency: Lizard.P('currency')
            });
            var showConfirm = function () {
                self.hideLoading();
                var cancelText = self.getTransValueByKey(TranslateKey.cancel) || "取消";
                var retryText = self.getTransValueByKey(TranslateKey.loadFailedRetryLater) || '加载失败，请稍后重试';
                var retryBtn = self.getTransValueByKey(TranslateKey.retry) || '重试';
                Lizard.showConfirm({
                    datamodel: {
                        content: retryText,
                        btns: [{ name: cancelText, className: 'cui-btns-cancel' },
                            { name: retryBtn, className: 'cui-btns-ok' }]
                    },
                    okAction: function () {
                        this.hide();
                        setTimeout(function () {
                            self.fetchVoiceDetail();
                        }, 300);
                    },
                    cancelAction: function () {
                        this.hide();
                        self.handleBack();
                    }
                });
            };
            var key = 'ticket_' + Number(Lizard.P('optionid'));
            var successCallback = function (rs) {
                self.hideLoading();
                if (rs.head.errcode !== 0) {
                    //有网情况没有拉取到数据也走缓存
                    rs = ticketVoiceDetailReqStore.getAttr(key);
                }
                if (!rs || !rs.data || !rs.data.resourceid) {
                    showConfirm();
                    return;
                }
                //有网状态设置缓存

                var retData = {};
                retData[key] = rs;
                ticketVoiceDetailReqStore.setData(retData);
                self._datas = rs.data || {};
                self._datas.isLogin = CommonStore.UserStore.getInstance().isLogin();
                self._datas.priceText = self._datas.currency + self._datas.price;
                //mock data
                // self._datas.goldMedalVoiceGuider = true;
                // self._datas.productFeature = 'Shanghai Town God&#39;s Temple to Yu Gardenw &Shanghai Town God&#39;s Temple to Park2 Audio Guide of the Forbidden City Audio Guide of the Forbidden City';
                // self._datas.voiceGuiderName = 'Michael Jackson';
                // self._datas.guiderDesc = 'Interpretation of the instructions';
                // self._datas.vendorBrandName = 'Provided by San Mao You San Mao You San San';
                // 初始化语音导游
                self.initVoicePoiDetail();
            };

            var errorCallback = function (err) {
                showConfirm();
            };

            if (this.hasNetwork) {
                this.instances.VoiceDetailModel.execute(successCallback, errorCallback);
            } else {
                var storeData = ticketVoiceDetailReqStore.getAttr(key);
                if (storeData) {
                    successCallback(storeData)
                } else {
                    showConfirm();
                }
            }

        },

        /**
         * @desc 二维码图片加载成功缓存
         */
        successCache: function (url) {
            if (url.indexOf('data:image/png;base64') !== -1) {
                return;
            }
            if (Lizard.isHybrid && window.CtripStorage) {
                var callback = function (base64) {
                    window.CtripStorage.app_storage_save(url, base64, 'rn_ttd', 24 * 60 * 60 * 30);
                };
                this.getBase64(url, callback)
            }
        },

        getBase64: function (url, callback) {
            url = url.trim();
            cGuiderService && cGuiderService.downloadData({
                url: url,
                suffix: url.substr(url.lastIndexOf('.') + 1),
                callback: function (data) {
                    if (data.savedPath) {
                        callback && callback(data.savedPath);
                    }
                }
            })
        },

        setHeader: function () {
            var self = this;
            isInApp && isIOS && CtripUtil.app_set_status_bar_style("darkContent");
            TicketCommon.hideHeader();
            isInApp && cHybridShell.off('back').on('back', function () {
                self.backHandler();
            });
        },
        /**
         * @description 渲染页面
         */
        render: function () {
            this.els.mainContainer.html(_.template(Lizard.T('entryTpl')));
        },
        destroyVoicePoiDetail: function () {
            this.voicePoiDetail && this.voicePoiDetail.removeIntervalUpdate();
            this.voicePoiDetail && this.voicePoiDetail.remove();
            this.voicePoiDetail = null;
            document.querySelector('body').classList.remove('nofastclick');
        },
        backHandler: function () {
            if (this.isInApp) {
                cGuider.backToLastPage();
            } else {
                TicketCommon.h5Back();
            }
        },

        /**
         * 返回 WIFI、2G、3G、4G、unknown、
         * @param callback
         */
        getNetworkType: function (callback) {
            if (!window || !window.CtripUtil || !window.CtripUtil.app_check_network_status) {
                callback && callback();
                return;
            }
            window.CtripUtil.app_check_network_status(function (typeInfo) {
                var type = 'NO';
                if (typeInfo && typeInfo.networkType) {
                    type = typeInfo.networkType.toUpperCase();
                    if (type === 'NONE' || type === 'NO CONNECTION') {
                        type = 'NO';
                    }
                }
                callback && callback(type);
            });
        }
    };

    return cPageView.extend(_.extend(_base, _ui, _methods));
});


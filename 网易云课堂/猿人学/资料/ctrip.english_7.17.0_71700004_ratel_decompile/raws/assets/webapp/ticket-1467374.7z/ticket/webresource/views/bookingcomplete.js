/**
 * @description 订单完成页
 * @author weiyh@Ctrip.com
 */
define(['require','TicketModel','cPageView','TicketCommon','JumpUtils','i18_en_us','i18_zh_hk','TranslateKey','cUtilHybrid','bookingCompleteVoice'],function (require) {

    var TicketModel = require('TicketModel'),

        cPageView = require('cPageView'),

        TicketCommon = require('TicketCommon'),

        JumpUtils = require('JumpUtils'),
        i18_en_us = require('i18_en_us'),
        i18_zh_hk = require('i18_zh_hk'),
        TranslateKey = require('TranslateKey'),
        cUtilHybrid = require('cUtilHybrid'),
        BookingCompleteVoice = require('bookingCompleteVoice');

    var i18n_100018464 = {
        'en-us': i18_en_us,
        'zh-hk': i18_zh_hk,
    };

    var orderDetailModel = TicketModel.NewOrderDetailModel.getInstance();

    var orderDetailTimeoutFlag = 0; // 包括初始化的，总共3次，5秒后刷新一次，10秒最后一次
    var isOrderDetailLoading = false; // 接口是否正在loading，如果是，不要再发起下一次

    var orderDetailSuccessFlag; // 订单详情接口成功标识


    var view = {
        name: 'bookingcomplete',
        showCancelRule: false,
        events: {},
        pageid: TicketCommon.pageid("bookingcomplete"),
        hpageid: TicketCommon.hpageid("bookingcomplete"),

        onCreate: function () {

            this.options = {
                // 当前订单的orderId
                orderId: parseInt(Lizard.P('oid') || Lizard.P('orderID') || Lizard.P('orderid')),
                locale: Lizard.P('locale') || 'en-US',
                currency: Lizard.P('currency') || '',
            };

        },


        onShow: function () {
            var locale = this.options.locale || 'en-US';
            this.i18trans = i18n_100018464[locale.toLowerCase()] || i18_en_us;

            this.needFresh = true;
            this._onShow();

            this.setViewData();
        },

        _onShow: function () {

            this.renderHeader();


            // 刷新订单信息的模块，为了展示入园凭证
            this.renderOrderDetail();
            // todo 这里最优化是应用队列来做
            this.orderDetailTimeoutId = setInterval(function () {
                if (this.orderDetailTimeoutId && orderDetailTimeoutFlag < 10 && this.needFresh) {
                    //needFresh条件 ：单资源，没有二维码或数字码，状态不是已成交或已确认，才会刷新
                    !isOrderDetailLoading && this.renderOrderDetail();
                } else {
                    clearInterval(this.orderDetailTimeoutId);
                    this.orderDetailTimeoutId = null;
                }
            }.bind(this), 1000);


        },


        getTransValueByKey: function (key) {
            return this.i18trans[key] || '';
        },

        stringProcess: function () {
            if (!arguments.length) {
                return '';
            }
            var args = Array.prototype.slice.call(arguments);
            var string = args[0];
            var rest = args.slice(1, args.length);
            for (var i = 0; i < rest.length; i++) {
                let index = string.indexOf('{' + i + '}');
                if (index > -1) {
                    string = string.split('');
                    string.splice(index, 2 + i.toString().length, rest[i]);
                    string = string.join('');
                }
            }
            return string
        },


        backHome: function () {   
            if(Lizard.isHybrid) {
                JumpUtils.jump('/rn_ibu_localtone/_crn_config', {
                    CRNModuleName: 'ibulocaltone',
                    CRNType: 1,
                    initialPage: 'mainPage',
                }, {
                    meta: { isDeleteCurrentPage: true }
                });
            } else {
                var domain = this.getDomain();
                var url = '//' + domain + '/m/things-to-do/';
                Lizard.jump(url, { targetModel: 4});
            }
        },


        /**
         * @desc 设定(更新)当前页面的view data
         * @param dataObj {object}
         */
        setViewData: function (dataObj) {
            if (dataObj === undefined) {
                this.data = {};
                return;
            }
            _.extend(this.data, dataObj);
        },


        renderOrderDetail: function () {

            isOrderDetailLoading = true;
            orderDetailModel.setParam({
                orderId: this.options.orderId,
                clientInfo: {
                    distributionChannelID: 25,//app
                    locale: this.options.locale,
                    currency: this.options.currency
                }
            });

            var voiceRenderer = function (data) {
                this.needFresh = true;
                BookingCompleteVoice.initVariable(this);
                BookingCompleteVoice.render(data, this);

            };

            var successHandler = function (data) {
                orderDetailTimeoutFlag++; // 接口请求标识
                isOrderDetailLoading = false;
                Lizard.hideLoading();
                if (Lizard.isHybrid) {
                    CtripUtil.app_h5_page_finish_loading();
                }
                voiceRenderer.call(this, data);
            };

            orderDetailModel.execute(function (res) {
                if (res && res.ResponseStatus && res.ResponseStatus.Ack === 'Success' && res.orderBasicInfoType) {
                    successHandler.call(this, $.extend({}, res.orderBasicInfoType, res.resourceInfoType));
                } else {
                    successHandler.call(this, {});
                }
            }, function () {
                successHandler.call(this, {});
            }, true, this);
        },

        getPageId: function () {
            return Lizard.isHybrid ? this.hpageid : this.pageid;
        },

        renderHeader: function () {
            var titleText = this.getTransValueByKey(TranslateKey.orderComplete) || "订单完成";
            $('.js_title_text').text(titleText);
        },

        onHide: function () {
            orderDetailModel.abort();
            if (this.orderDetailTimeoutId) {
                clearInterval(this.orderDetailTimeoutId);
                this.orderDetailTimeoutId = null;
            }
            orderDetailTimeoutFlag = 0;
            orderDetailSuccessFlag = void 0;
        },

        goOrderDetail: function () {
            if(Lizard.isHybrid) {
                JumpUtils.jump('/rn_ibu_localtone/_crn_config', {
                    CRNModuleName: 'ibulocaltone',
                    CRNType: 1,
                    orderid: this.options.orderId,
                    initialPage: 'orderdetail',
                }, {
                    meta: { isDeleteCurrentPage: true }
                });
            } else {
                var domain = this.getDomain();
                var url = '//' + domain + '/m/things-to-do/orderdetail?orderid=' + this.options.orderId;
                Lizard.jump(url, { targetModel: 4});
            }
        },

        getDomain: function (){
            var env = cUtilHybrid && cUtilHybrid.isPreProduction();
            var domain = '';
            switch(env) {
                case 0: // fat
                    domain = 'www.fat1.qa.nt.tripcorp.com';
                    break;
                case 2: //uat
                    domain = 'www.uat.tripcorp.com';
                    break;
                case 1: //堡垒
                default:
                    domain = 'www.trip.com';
                    break;
            }
            return domain;
        }
    };
    var categories = [BookingCompleteVoice];
    var events = view.events;
    categories.forEach(function (item) {
        _.extend(events, item.events);
        // _.extend(view, item);
    });
    view.events = events;

    return cPageView.extend(_.extend(view));
});


<div class="site-info">
<?php
echo '<p class="copyright">' . __( 'Copyright &#169; ', 'winter-solstice' ) . date_i18n( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '.</p>' . "\n\n" . '<p class="credit">' . winter_solstice_theme_link() . '</p>';	
?>
</div><!-- .site-info -->

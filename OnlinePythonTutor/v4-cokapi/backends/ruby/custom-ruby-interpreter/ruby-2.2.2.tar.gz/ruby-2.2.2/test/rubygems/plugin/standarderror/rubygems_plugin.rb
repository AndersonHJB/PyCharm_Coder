TestGem::TEST_PLUGIN_STANDARDERROR = :loaded
raise StandardError.new('boom')

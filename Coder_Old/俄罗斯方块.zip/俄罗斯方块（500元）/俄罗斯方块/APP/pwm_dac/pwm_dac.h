#ifndef _pwm_dac_H
#define _pwm_dac_H

#include "system.h"

void TIM4_CH1_PWM_Init(u16 arr,u16 psc);

#endif


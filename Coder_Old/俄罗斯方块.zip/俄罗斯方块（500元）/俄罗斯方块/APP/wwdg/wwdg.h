#ifndef _wwdg_H
#define _wwdg_H


#include "system.h"

void WWDG_Init(void);

#endif

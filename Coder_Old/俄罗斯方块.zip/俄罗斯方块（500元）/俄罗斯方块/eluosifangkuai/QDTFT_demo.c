/* --------------------------Includes ---------------------------------------------*/
#include "stm32f10x.h"
#include "Lcd_Driver.h"
#include "GUI.h"
#include "SysTick.h"
#include "Picture.h"
#include "QDTFT_demo.h"
/* ----------------------End of Includes ---------------------------------------------*/




//void showimage(const unsigned char *p) //��ʾ40*40 QQͼƬ
//{
//  	int i; 
//	unsigned char picH,picL; 
//	Lcd_Clear(WHITE);
////	Gui_DrawFont_GBK16(16,10,BLUE,GRAY0,"ͼƬ��ʾ����");
////	delay_ms(1000);

//	Lcd_Clear(WHITE);

//			Lcd_SetRegion(18,0,18+142,0+240);		//��������
//		    for(i=0;i<143*143;i++)
//			 {	
//			 	picL=*(p+i*2);	//���ݵ�λ��ǰ
//				picH=*(p+i*2+1);				
//				Lcd_WriteData_16Bit(picH<<8|picL);  						
//	}	
//}
////�ۺϲ��Ժ���
//void QDTFT_Test_Demo(void)
//{
//	showimage(gImage_xiaohui);
//	Gui_DrawFont_GBK16(33,153,BLUE,WHITE,"�������Ƽ���ѧ");
//	Gui_DrawFont_GBK16(33,179,BLUE,WHITE,"����ߣ������");
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);

//}

/***************************************
����˵��:
//-------------------------------------------------------------------------------------
#define LCD_CTRL   	  	GPIOB		//����TFT���ݶ˿�
#define LCD_LED        	GPIO_Pin_9  //PB9 ������TFT -LED
#define LCD_RS         	GPIO_Pin_10	//PB10������TFT --RS
#define LCD_CS        	GPIO_Pin_11 //PB11 ������TFT --CS
#define LCD_RST     	GPIO_Pin_12	//PB12������TFT --RST
#define LCD_SCL        	GPIO_Pin_13	//PB13������TFT -- CLK
#define LCD_SDA        	GPIO_Pin_15	//PB15������TFT - SDI
//VCC:���Խ�5VҲ���Խ�3.3V
//LED:���Խ�5VҲ���Խ�3.3V����ʹ���������IO����(�ߵ�ƽʹ��)
//GND���ӵ�Դ��
//˵��������Ҫ��������ռ��IO�����Խ�LCD_CS�ӵأ�LCD_LED��3.3V��LCD_RST������Ƭ����λ�ˣ�
//�������ͷ�3������IO
//-----------------------------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "box.h"
#include "Lcd_Driver.h"
#include "GUI.h"
#include "box.h"
#include "time.h"
#include "SysTick.h"
#include "key.h"
#include "stdio.h"
#include "stdlib.h"
#include "adc.h"
#include "QDTFT_demo.h"


u8 what,speed=80,i=0,game=1,leave=1,suijishu[5];
u16 x=60,y=0,fengshu=0;
u8 shuaxing=0;
u8 zhuangtai[23][16]=
{
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********0**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********1**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********2**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********3**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********4**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********5**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********6**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********7**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********8**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********9**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********10**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********11**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********12**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********13**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********14**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********15**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********16**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********17**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********18**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********19**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********20**********//
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},//**********21**********//
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},//**********22**********//
};












/*************************************************
���ܣ�����һ��״̬������
*************************************************/
void Draw_a_zhuangtai(u16 x,u16 y)
{
	  zhuangtai[y/10][x/10+1]=1;
}


/*************************************************
���ܣ�ɾ��һ��״̬������
*************************************************/
void Deal_a_zhuangtai(u16 x,u16 y)
{
	  zhuangtai[y/10][x/10+1]=0;
}



/*************************************************
���ܣ�����Ӧ��״̬ͼ��
*************************************************/
void Draw_zhuangtai_tuxing(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		}
		break;
		
		case 2:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+20,y);
		Draw_a_zhuangtai(x+30,y);
		}
		break;
		
		case 3:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x,y+20);
		Draw_a_zhuangtai(x,y+30);
		}
		break;
		
		case 4:
		{
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 5:
		{
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x,y+20);
		}
		break;

		case 6:
		{
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 7:
		{
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+20,y);
		}
		break;
	
		case 8:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x,y+20);
		Draw_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 9:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+20,y);
		}
		break;
		
		case 10:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 11:
		{
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+20,y+10);
		Draw_a_zhuangtai(x+20,y);
		}
		break;
		
		case 12:
		{
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+10,y+20);
		Draw_a_zhuangtai(x,y+20);
		}
		break;
		
		case 13:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+20,y);
		Draw_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 14:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x,y+20);
		}
		break;
		
		case 15:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+20,y+10);
		}
		break;
		
		
		case 16:
		{
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x,y+20);
		}
		break;
		
		case 17:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 18:
		{
		Draw_a_zhuangtai(x,y);
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 19:
		{
		Draw_a_zhuangtai(x,y+10);
		Draw_a_zhuangtai(x+10,y+10);
		Draw_a_zhuangtai(x+10,y);
		Draw_a_zhuangtai(x+20,y);
		}
		break;
	
	
	
	
	}

}



/*************************************************
���ܣ�ɾ����Ӧ��״̬ͼ��
*************************************************/
void Deal_zhuangtai_tuxing(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		}
		break;
		
		case 2:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+20,y);
		Deal_a_zhuangtai(x+30,y);
		}
		break;
		
		case 3:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x,y+20);
		Deal_a_zhuangtai(x,y+30);
		}
		break;
		
		case 4:
		{
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 5:
		{
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x,y+20);
		}
		break;

		case 6:
		{
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 7:
		{
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+20,y);
		}
		break;
	
		case 8:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x,y+20);
		Deal_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 9:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+20,y);
		}
		break;
		
		case 10:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 11:
		{
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+20,y+10);
		Deal_a_zhuangtai(x+20,y);
		}
		break;
		
		case 12:
		{
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+10,y+20);
		Deal_a_zhuangtai(x,y+20);
		}
		break;
		
		case 13:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+20,y);
		Deal_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 14:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x,y+20);
		}
		break;
		
		case 15:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 16:
		{
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x,y+20);
		}
		break;
		
		case 17:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+20,y+10);
		}
		break;
		
		case 18:
		{
		Deal_a_zhuangtai(x,y);
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+10,y+20);
		}
		break;
		
		case 19:
		{
		Deal_a_zhuangtai(x,y+10);
		Deal_a_zhuangtai(x+10,y+10);
		Deal_a_zhuangtai(x+10,y);
		Deal_a_zhuangtai(x+20,y);
		}
		break;
	}

}

/*************************************************
���ܣ������ƶ�״̬
*************************************************/

void Down_zhuangtai_move(u16 x,u16 y,u16 what)
{
	Deal_zhuangtai_tuxing(x,y,what);
	Draw_zhuangtai_tuxing(x,y+10,what);
}

/*************************************************
���ܣ������ƶ�״̬
*************************************************/
void Left_zhuangtai_move(u16 x,u16 y,u8 what)
{
	Deal_zhuangtai_tuxing(x,y,what);
	Draw_zhuangtai_tuxing(x-10,y,what);
}

/*************************************************
���ܣ������ƶ�״̬
*************************************************/
void Right_zhuangtai_move(u16 x,u16 y,u8 what)
{
	Deal_zhuangtai_tuxing(x,y,what);
	Draw_zhuangtai_tuxing(x+10,y,what);
}









void Down(u16 x,u16 y,u8 what)
{
	Down_zhuangtai_move(x,y,what);
	Down_tuxing_move(x,y,what);			
}


void Left(u16 x,u16 y,u8 what)
{
	Left_zhuangtai_move(x,y,what);
	Left_tuxing_move(x,y,what);			
}


void Right(u16 x,u16 y,u8 what)
{
	Right_zhuangtai_move(x,y,what);
	Right_tuxing_move(x,y,what);			
}


void Deal(u16 x,u16 y,u8 what)
{
	Deal_tuxing(x,y,what);
	Deal_zhuangtai_tuxing(x,y,what);			
}



void Draw(u16 x,u16 y,u8 what)
{
	Draw_tuxing(x,y,what);
	Draw_zhuangtai_tuxing(x,y,what);			
}




//���ܣ��ж��Ƿ���ײ���ص㣩����

//int panduan(u16 x,u16 y,u8 what,u8 fangxiang)
//{
//	x=x/10+1;
//	y=y/10;
//	switch(what)
//	{
//		case 1: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+2][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+2])return 1; else return 0;
//		  }	
//		}			

//		
//		case 2: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+1][x]||zhuangtai[y+1][x+1]||zhuangtai[y+1][x+2]==1||zhuangtai[y+1][x+3])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+4])return 1; else return 0;
//		  }	
//		}			

//	  
//		case 3: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x-1]||zhuangtai[y+3][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+4][x])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+1]||zhuangtai[y+1][x+1]||zhuangtai[y+2][x+1]||zhuangtai[y+3][x+1])return 1; else return 0;
//		  }	
//		}			

//		
//		case 4: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y+1][x-1]||zhuangtai[y][x])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+2][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+3])return 1; else return 0;
//		  }	
//		}			

//		
//		case 5: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x-1]==1)return 1; else return 0;
//				case 2:if(zhuangtai[y+3][x]||zhuangtai[y+2][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+1]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+1]==1)return 1; else return 0;
//		  }	
//		}			

//		
//		case 6: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x]==1)return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+3][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+3])return 1; else return 0;
//		  }	
//		}			

//		
//		case 7: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x])return 1; else return 0;
//				case 2:if(zhuangtai[y+1][x]||zhuangtai[y+2][x+1]||zhuangtai[y+1][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+3]||zhuangtai[y+1][x+2])return 1; else return 0;
//		  }	
//		}			

//		
//		case 8: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+3][x]||zhuangtai[y+3][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+1]||zhuangtai[y+1][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//		  }	
//		}			
//	
//		
//		case 9: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+1][x+1]||zhuangtai[y+1][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+3]||zhuangtai[y+1][x+1])return 1; else return 0;
//		  }	
//		}			
//	
//		
//		case 10: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x]||zhuangtai[y+2][x])return 1; else return 0;
//				case 2:if(zhuangtai[y+1][x]||zhuangtai[y+3][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+2])return 1; else return 0;
//		  }	
//		}			
//		
//		case 11: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y+1][x-1]||zhuangtai[y][x+1])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+2][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+3]||zhuangtai[y+1][x+3])return 1; else return 0;
//		  }	
//		}
//		
//		case 12: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x]||zhuangtai[y+1][x]||zhuangtai[y+2][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+3][x]||zhuangtai[y+3][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+2])return 1; else return 0;
//		  }	
//		}
//		
//		case 13: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x+1])return 1; else return 0;
//				case 2:if(zhuangtai[y+1][x]||zhuangtai[y+1][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+3]||zhuangtai[y+1][x+3])return 1; else return 0;
//		  }	
//		}
//		
//		case 14: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+3][x]||zhuangtai[y+1][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//		  }	
//		}
//		
//		case 15: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+2][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+1]||zhuangtai[y+1][x+3])return 1; else return 0;
//		  }	
//		}
//		
//		case 16: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+3][x]||zhuangtai[y+2][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+1])return 1; else return 0;
//		  }	
//		}
//		
//		case 17: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x])return 1; else return 0;
//				case 2:if(zhuangtai[y+1][x]||zhuangtai[y+2][x+1]||zhuangtai[y+2][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+2]||zhuangtai[y+1][x+3])return 1; else return 0;
//		  }	
//		}
//		
//		case 18: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x-1]||zhuangtai[y+1][x-1]||zhuangtai[y+2][x])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+3][x+1])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+1]||zhuangtai[y+1][x+2]||zhuangtai[y+2][x+2])return 1; else return 0;
//		  }	
//		}
//		
//		case 19: 
//		{
//		switch(fangxiang)
//			{
//			  case 1:if(zhuangtai[y][x]||zhuangtai[y+1][x-1])return 1; else return 0;
//				case 2:if(zhuangtai[y+2][x]||zhuangtai[y+2][x+1]||zhuangtai[y+1][x+2])return 1; else return 0;
//				case 3:if(zhuangtai[y][x+3]||zhuangtai[y+1][x+2])return 1; else return 0;
//		  }	
//		}		
//	}
//	
//}













void change()
{
	
	switch(what)
	{
		case 1:break;
		
		case 2:Deal(x,y,2);Draw(x,y,3);what=3;break;
		case 3:Deal(x,y,3);Draw(x,y,2);what=2;break;
		
		case 4:Deal(x,y,4);Draw(x,y,5);what=5;break;
		case 5:Deal(x,y,5);Draw(x,y,7);what=7;break;
		case 6:Deal(x,y,6);Draw(x,y,4);what=4;break;
		case 7:Deal(x,y,7);Draw(x,y,6);what=6;break;
		
		case 8:Deal(x,y,8);Draw(x,y,9);what=9;break;
		case 9:Deal(x,y,9);Draw(x,y,10);what=10;break;
		case 10:Deal(x,y,10);Draw(x,y,11);what=11;break;
		case 11:Deal(x,y,11);Draw(x,y,8);what=8;break;
		
		case 12:Deal(x,y,12);Draw(x,y,15);what=15;break;
		case 13:Deal(x,y,13);Draw(x,y,12);what=12;break;
		case 14:Deal(x,y,14);Draw(x,y,13);what=13;break;
		case 15:Deal(x,y,15);Draw(x,y,14);what=14;break;
		
		case 16:Deal(x,y,16);Draw(x,y,17);what=17;break;
		case 17:Deal(x,y,17);Draw(x,y,16);what=16;break;
		
		case 18:Deal(x,y,18);Draw(x,y,19);what=19;break;
		case 19:Deal(x,y,19);Draw(x,y,18);what=18;break;
	
	}





}


void change1()
{
	
	switch(what)
	{
		case 1:break;
		
		case 2:Deal_zhuangtai_tuxing(x,y,2);Draw_zhuangtai_tuxing(x,y,3);break;
		case 3:Deal_zhuangtai_tuxing(x,y,3);Draw_zhuangtai_tuxing(x,y,2);break;
		
		case 4:Deal_zhuangtai_tuxing(x,y,4);Draw_zhuangtai_tuxing(x,y,5);break;
		case 5:Deal_zhuangtai_tuxing(x,y,5);Draw_zhuangtai_tuxing(x,y,7);break;
		case 6:Deal_zhuangtai_tuxing(x,y,6);Draw_zhuangtai_tuxing(x,y,4);break;
		case 7:Deal_zhuangtai_tuxing(x,y,7);Draw_zhuangtai_tuxing(x,y,6);break;
		
		case 8:Deal_zhuangtai_tuxing(x,y,8);Draw_zhuangtai_tuxing(x,y,9);break;
		case 9:Deal_zhuangtai_tuxing(x,y,9);Draw_zhuangtai_tuxing(x,y,10);break;
		case 10:Deal_zhuangtai_tuxing(x,y,10);Draw_zhuangtai_tuxing(x,y,11);break;
		case 11:Deal_zhuangtai_tuxing(x,y,11);Draw_zhuangtai_tuxing(x,y,8);break;
			
		case 12:Deal_zhuangtai_tuxing(x,y,12);Draw_zhuangtai_tuxing(x,y,15);break;
		case 13:Deal_zhuangtai_tuxing(x,y,13);Draw_zhuangtai_tuxing(x,y,12);break;
		case 14:Deal_zhuangtai_tuxing(x,y,14);Draw_zhuangtai_tuxing(x,y,13);break;
		case 15:Deal_zhuangtai_tuxing(x,y,15);Draw_zhuangtai_tuxing(x,y,14);break;
		
		case 16:Deal_zhuangtai_tuxing(x,y,16);Draw_zhuangtai_tuxing(x,y,17);break;
		case 17:Deal_zhuangtai_tuxing(x,y,17);Draw_zhuangtai_tuxing(x,y,16);break;
		
		case 18:Deal_zhuangtai_tuxing(x,y,18);Draw_zhuangtai_tuxing(x,y,19);break;
		case 19:Deal_zhuangtai_tuxing(x,y,19);Draw_zhuangtai_tuxing(x,y,18);break;
	
	}





}





int panduan1(u16 x,u16 y,u8 what,u8 fangxiang)

{
	u16 sum1=0,sum2=0;
	u8 i,n;
	u8 sbuff[23][16];
	x=x/10+1;
	y=y/10;
	for(i=0;i<23;i++)
	{
	
		for(n=0;n<16;n++)
		{
			sbuff[i][n]=zhuangtai[i][n];
			sum1=sum1+zhuangtai[i][n];	
		}
	  
	}
			
	
	switch(fangxiang)
	{
		case 1:Left_zhuangtai_move((x-1)*10,10*y,what);break;
		case 2:Down_zhuangtai_move((x-1)*10,10*y,what);break;
		case 3:Right_zhuangtai_move((x-1)*10,10*y,what);break;
		case 4:change1();break;
		
	}
		for(i=0;i<23;i++)
	{
		
		for(n=0;n<16;n++)
		{
			sum2=sum2+zhuangtai[i][n];	
			zhuangtai[i][n]=sbuff[i][n];			
    }
	}
	
		
		return !(sum1==sum2);
}



void lie_move(u16 y)
{
	u8 i;
	y=y/10;
	for(i=1;i<15;i++)
	{
		if(zhuangtai[y][i]==1)
		{
			zhuangtai[y][i]=zhuangtai[y+1][i];
			zhuangtai[y+1][i]=1;
			
				Deal_realbox((i-1)*10,y*10);
			Draw_realbox((i-1)*10,(y+1)*10);
		}
		else if(zhuangtai[y][i]==0)
		{
			zhuangtai[y][i]=zhuangtai[y+1][i];
			zhuangtai[y+1][i]=0;
			
				Deal_realbox((i-1)*10,y*10);
			Deal_realbox((i-1)*10,(y+1)*10);
		}
	}
}


void Deal_lie(u16 y)
{
	u8 i;
	y=y/10;
	for(i=1;i<15;i++)
	{
		zhuangtai[y][i]=0;
		Deal_realbox((i-1)*10,y*10);
	}
}







void display_leave()
{
	switch(leave)
	{
		case 0:Gui_DrawFont_GBK16(155,182,RED,WHITE,"0");break;	
		case 1:Gui_DrawFont_GBK16(155,182,RED,WHITE,"1");break;	
		case 2:Gui_DrawFont_GBK16(155,182,RED,WHITE,"2");break;	
		case 3:Gui_DrawFont_GBK16(155,182,RED,WHITE,"3");break;	
		case 4:Gui_DrawFont_GBK16(155,182,RED,WHITE,"4");break;	
		case 5:Gui_DrawFont_GBK16(155,182,RED,WHITE,"5");break;	
		case 6:Gui_DrawFont_GBK16(155,182,RED,WHITE,"6");break;	
		case 7:Gui_DrawFont_GBK16(155,182,RED,WHITE,"7");break;
		case 8:Gui_DrawFont_GBK16(155,182,RED,WHITE,"8");break;	
		case 9:Gui_DrawFont_GBK16(155,182,RED,WHITE,"9");break;			
	}


}






void display_fengshu()
{
	u8 shi,ge;
	shi=fengshu/10;
	ge=fengshu%10;
	switch(shi)
	{
		case 0:Gui_DrawFont_GBK16(150,122,RED,WHITE,"0");break;	
		case 1:Gui_DrawFont_GBK16(150,122,RED,WHITE,"1");break;	
		case 2:Gui_DrawFont_GBK16(150,122,RED,WHITE,"2");break;	
		case 3:Gui_DrawFont_GBK16(150,122,RED,WHITE,"3");break;	
		case 4:Gui_DrawFont_GBK16(150,122,RED,WHITE,"4");break;	
		case 5:Gui_DrawFont_GBK16(150,122,RED,WHITE,"5");break;	
		case 6:Gui_DrawFont_GBK16(150,122,RED,WHITE,"6");break;	
		case 7:Gui_DrawFont_GBK16(150,122,RED,WHITE,"7");break;
		case 8:Gui_DrawFont_GBK16(150,122,RED,WHITE,"8");break;	
		case 9:Gui_DrawFont_GBK16(150,122,RED,WHITE,"9");break;			
	}
	
	switch(ge)
	{
		case 0:Gui_DrawFont_GBK16(160,122,RED,WHITE,"0");break;	
		case 1:Gui_DrawFont_GBK16(160,122,RED,WHITE,"1");break;	
		case 2:Gui_DrawFont_GBK16(160,122,RED,WHITE,"2");break;	
		case 3:Gui_DrawFont_GBK16(160,122,RED,WHITE,"3");break;	
		case 4:Gui_DrawFont_GBK16(160,122,RED,WHITE,"4");break;	
		case 5:Gui_DrawFont_GBK16(160,122,RED,WHITE,"5");break;	
		case 6:Gui_DrawFont_GBK16(160,122,RED,WHITE,"6");break;	
		case 7:Gui_DrawFont_GBK16(160,122,RED,WHITE,"7");break;
		case 8:Gui_DrawFont_GBK16(160,122,RED,WHITE,"8");break;	
		case 9:Gui_DrawFont_GBK16(160,122,RED,WHITE,"9");break;			
	}



}






void xiaochu()
{
	u8 n;
	for(n=20;n>0;n--)
	{
		if(n>=20)
		{
			n=20;
		
		
		}
		if(
					
					(
					zhuangtai[n+1][1]&&zhuangtai[n+1][2]&&zhuangtai[n+1][3]&&zhuangtai[n+1][4]&&zhuangtai[n+1][5]&&zhuangtai[n+1][6]&&zhuangtai[n+1][7]&&zhuangtai[n+1][8]&&zhuangtai[n+1][9]&&zhuangtai[n+1][10]&&zhuangtai[n+1][11]&&zhuangtai[n+1][12]&&zhuangtai[n+1][13]&&zhuangtai[n+1][14]
					) 
				 &&
					!(
					zhuangtai[n][1]&&zhuangtai[n][2]&&zhuangtai[n][3]&&zhuangtai[n][4]&&zhuangtai[n][5]&&zhuangtai[n][6]&&zhuangtai[n][7]&&zhuangtai[n][8]&&zhuangtai[n][9]&&zhuangtai[n][10]&&zhuangtai[n][11]&&zhuangtai[n][12]&&zhuangtai[n][13]&&zhuangtai[n][14]
					)
		   )
		  
		

		{
			lie_move(10*n);

			n=n+2;
		}
		
		if(
					(
					!zhuangtai[n][1]&&!zhuangtai[n][2]&&!zhuangtai[n][3]&&!zhuangtai[n][4]&&!zhuangtai[n][5]&&!zhuangtai[n][6]&&!zhuangtai[n][7]&&!zhuangtai[n][8]&&!zhuangtai[n][9]&&!zhuangtai[n][10]&&!zhuangtai[n][11]&&!zhuangtai[n][12]&&!zhuangtai[n][13]&&!zhuangtai[n][14]
					)
		  )
		{
			for(n=0;n<22;n++)
	{
		if(
				(
				zhuangtai[n][1]&&zhuangtai[n][2]&&zhuangtai[n][3]&&zhuangtai[n][4]&&zhuangtai[n][5]&&zhuangtai[n][6]&&zhuangtai[n][7]&&zhuangtai[n][8]&&zhuangtai[n][9]&&zhuangtai[n][10]&&zhuangtai[n][11]&&zhuangtai[n][12]&&zhuangtai[n][13]&&zhuangtai[n][14]
				)
		  )
		{
			Deal_lie(n*10);fengshu++;display_fengshu();
				if(fengshu%10==0)
				{
					speed=speed-10;
					leave++;
					display_leave();				
				}
		}	
	}
	break;		
		}
	}
}










void game_over()
{
	u8 x;
	game=3;
	
	for(x=0;x<=86;x++)
	{
   	Gui_DrawLine(x+86,60,x+86,165,WHITE);
		Gui_DrawLine(86-x,60,86-x,165,WHITE);
	}
	
	Gui_DrawFont_GBK24(40,65,BLUE,WHITE,"��Ϸ����");
	Gui_DrawFont_GBK24(12,100,BLUE,WHITE,"���ε÷֣�");
	Gui_DrawFont_Num32(114,95,RED,WHITE,fengshu/10);
	Gui_DrawFont_Num32(138,95,RED,WHITE,fengshu%10);
	Gui_DrawFont_GBK24(4,135,BLUE,WHITE,"�밴���ϡ�����");
}

void first()
{ u8 i,n;
	fengshu=0;
	leave=1;
	speed=80;
	Lcd_Clear(WHITE);
  Gui_DrawLine(140,0,140,220,BLACK);
	for(i=0;i<22;i++)
	{
	
		for(n=1;n<15;n++)
		{
			zhuangtai[i][n]=0;
		}
	  
	}
	Gui_DrawFont_GBK16(143,5,BLUE,WHITE,"NEXT");
	
	Gui_DrawFont_GBK16(143,100,BLUE,WHITE,"�÷�");
	Gui_DrawFont_GBK16(160,122,RED,WHITE,"0");
  Gui_DrawFont_GBK16(150,122,RED,WHITE,"0");
	
	Gui_DrawFont_GBK16(143,160,BLUE,WHITE,"�ȼ�");
	Gui_DrawFont_GBK16(155,182,RED,WHITE,"1");

}



void begin()
{
	
	Deal_tuxing1(150,25,suijishu[4]);
	Deal_tuxing1(150,50,suijishu[3]);
	Deal_tuxing1(150,75,suijishu[2]);
	
	
	
	what=suijishu[4];
	suijishu[4]=suijishu[3];
	suijishu[3]=suijishu[2];
	suijishu[2]=suijishu[1];
	suijishu[1]=suijishu[0];
	//srand(Get_ADC_Value(3,1)*115);
	suijishu[0]=rand()%19+1;
	
	
	Draw_tuxing1(150,25,suijishu[4]);
	Draw_tuxing1(150,50,suijishu[3]);
	Draw_tuxing1(150,75,suijishu[2]);
	




	
	x=60,y=0;
	
	Draw(60,0,what);	
	if(panduan1(x,y,what,2))
	{
		game_over();
	}
	
}


void welcome()
{
	
	
	Lcd_Clear(WHITE);
	Gui_DrawFont_GBK24(40,70,BLUE,WHITE,"��ӭ����");
	Gui_DrawFont_GBK24(27,100,BLUE,WHITE,"����˹����");
	Gui_DrawFont_GBK24(5,143,BLUE,WHITE,"�밴���ϡ���ʼ");
//	


}










void stop()
{
	u8 x;
	for(x=0;x<=86;x++)
	{
   	Gui_DrawLine(x+86,60,x+86,165,WHITE);
		Gui_DrawLine(86-x,60,86-x,165,WHITE);
	}
	
	Gui_DrawFont_GBK24(30,80,BLUE,WHITE,"��Ϸ����ͣ");
	Gui_DrawFont_GBK24(4,120,BLUE,WHITE,"�밴���ϡ�����");
	
	TIM4->CR1 &= ~(0x01);
}	




void star()
{
	u8 x,y;
	for(x=0;x<=86;x++)
	{
   	Gui_DrawLine(x+86,60,x+86,165,WHITE);
		Gui_DrawLine(86-x,60,86-x,165,WHITE);
	}
	
	Gui_DrawLine(140,0,140,220,BLACK);
	
	Gui_DrawFont_GBK16(143,5,BLUE,WHITE,"NEXT");
	
	Draw_tuxing1(150,25,suijishu[4]);
	Draw_tuxing1(150,50,suijishu[3]);
	Draw_tuxing1(150,75,suijishu[2]);
	
	Gui_DrawFont_GBK16(143,100,BLUE,WHITE,"�÷�");
	display_fengshu();
	
	Gui_DrawFont_GBK16(143,160,BLUE,WHITE,"�ȼ�");
	display_leave();
	
	
	for(x=1;x<15;x++)
	{
		for(y=5;y<20;y++)
	{
		if(zhuangtai[y][x])
			Draw_realbox((x-1)*10,y*10);
		
		
		
	}
	}
		
	TIM4_Init(20,36000-1);
}
	





int main(void)
{
  SystemInit();	
  SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��	
	
	KEY_Init();
	Lcd_Init();
	welcome();
	//ADCx_Init();
	TIM4_Init(20,36000-1);
	Lcd_Clear(WHITE); 
	welcome();
	
	delay_ms(10);
	//srand(Get_ADC_Value(3,1)*115);
	suijishu[0]=rand()%19+1;
	suijishu[1]=rand()%19+1;
	suijishu[2]=rand()%19+1;
	suijishu[3]=rand()%19+1;
	suijishu[4]=rand()%19+1;
	
	


	

	
	
	

	
	while(1)
	{
		
		
		
		switch(KEY_Scan())
		{
			case 0:break;
			case 1:
				if(game==1)
				{game=2;first();begin();}
				else if(game==2)
				{game=4;stop();}
				else if(game==4)
				{game=2;star();}
				else if(game==3)
				{game=1;welcome();}
			break;
			
			case 2:if(game!=2)break;if(!panduan1(x,y,what,2)){Down(x,y,what);y=y+10;}else{	xiaochu();begin();} break;
			case 3:if(game!=2)break;if(!panduan1(x,y,what,1)){Left(x,y,what);x=x-10;}break;
			case 4:if(game!=2)break;if(!panduan1(x,y,what,3)){Right(x,y,what);x=x+10;}break;
			case 5:if(game!=2)break;if(!panduan1(x,y,what,4))change();break;
	  	
		}
		
		
		
		if(game==2)
		{
		if(i>speed)
		{
			i=0;
		
		if(panduan1(x,y,what,2))
			{
//				lie_move(200);
				xiaochu();
				begin();							
		  }
			else
			{
				Down(x,y,what);				
				y=y+10;		
			}
		}
			


 
}
	}
}
void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update))
	{
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
		i++;
	}
	
}



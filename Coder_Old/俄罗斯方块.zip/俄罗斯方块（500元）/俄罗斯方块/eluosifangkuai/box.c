#include "Lcd_Driver.h"
#include "box.h"
extern u8 zhuangtai[15][22];

/*************************************************
������ Draw_realbox
���ܣ���һ������˹���飻
��ڲ�����xy����
����ֵ����
*************************************************/
void Draw_realbox(u16 x,u16 y)
{
	u8 i,n;
	for(i=1;i<=8;i++)
	{
		for(n=1;n<=8;n++)
		{
			Gui_DrawPoint((x+i),(y+n),GRAY0);	
		}	
	}
	for(i=0;i<=9;i++)
	{
		Gui_DrawPoint((x+i),y,BLACK	);
		Gui_DrawPoint((x+i),(y+9),BLACK	);		
		Gui_DrawPoint(x,(y+i),BLACK	);		
		Gui_DrawPoint((x+9),(y+i),BLACK	);				
	}	
}

void Draw_realbox1(u16 x,u16 y)
{
	u8 i,n;
	for(i=1;i<=3;i++)
	{
		for(n=1;n<=3;n++)
		{
			Gui_DrawPoint((x+i),(y+n),GRAY0);	
		}	
	}
	for(i=0;i<=4;i++)
	{
		Gui_DrawPoint((x+i),y,BLACK	);
		Gui_DrawPoint((x+i),(y+4),BLACK	);		
		Gui_DrawPoint(x,(y+i),BLACK	);		
		Gui_DrawPoint((x+4),(y+i),BLACK	);				
	}	
}


/*************************************************
������ Deal_realbox
���ܣ�ɾ��һ������˹���飻
��ڲ�����xy����
����ֵ����
*************************************************/
void Deal_realbox(u16 x,u16 y)
{
	u8 i,n;
	for(i=0;i<=9;i++)
	{
		for(n=0;n<=9;n++)
		{
			Gui_DrawPoint((x+i),(y+n),WHITE);	
		}	
	}
}


void Deal_realbox1(u16 x,u16 y)
{
	u8 i,n;
	for(i=0;i<=4;i++)
	{
		for(n=0;n<=4;n++)
		{
			Gui_DrawPoint((x+i),(y+n),WHITE);	
		}	
	}
}



/*************************************************
������ Draw_tuxing
���ܣ�
��ڲ�����xy����
����ֵ����
*************************************************/
void Draw_tuxing(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		}
		break;
		
		case 2:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x+20,y);
		Draw_realbox(x+30,y);
		}
		break;
		
		case 3:
		{
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x,y+20);
		Draw_realbox(x,y+30);
		}
		break;
		
		case 4:
		{
		Draw_realbox(x+10,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+20,y+10);
		}
		break;
		
		case 5:
		{
		Draw_realbox(x+10,y+10);
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x,y+20);
		}
		break;

		case 6:
		{
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+10,y+20);
		}
		break;
		
		case 7:
		{
		Draw_realbox(x+10,y+10);
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x+20,y);
		}
		break;
	
		case 8:
		{
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x,y+20);
		Draw_realbox(x+10,y+20);
		}
		break;
		
		case 9:
		{
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y);
		Draw_realbox(x+20,y);
		}
		break;
		
		case 10:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+10,y+20);
		}
		break;
		
		case 11:
		{
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+20,y+10);
		Draw_realbox(x+20,y);
		}
		break;
		
		case 12:
		{
		Draw_realbox(x+10,y);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+10,y+20);
		Draw_realbox(x,y+20);
		}
		break;
		
		case 13:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x+20,y);
		Draw_realbox(x+20,y+10);
		}
		break;
		
		case 14:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x,y+20);
		}
		break;
		
		case 15:
		{
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+20,y+10);
		}
		break;
		
		
		case 16:
		{
		Draw_realbox(x+10,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x,y+20);
		}
		break;
		
		case 17:
		{
		Draw_realbox(x,y);
		Draw_realbox(x+10,y);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+20,y+10);
		}
		break;
		
		case 18:
		{
		Draw_realbox(x,y);
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+10,y+20);
		}
		break;
		
		case 19:
		{
		Draw_realbox(x,y+10);
		Draw_realbox(x+10,y+10);
		Draw_realbox(x+10,y);
		Draw_realbox(x+20,y);
		}
		break;
	
	
	
	
	}

}




void Draw_tuxing1(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		}
		break;
		
		case 2:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+10,y);
		Draw_realbox1(x+15,y);
		}
		break;
		
		case 3:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x,y+10);
		Draw_realbox1(x,y+15);
		}
		break;
		
		case 4:
		{
		Draw_realbox1(x+5,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+10,y+5);
		}
		break;
		
		case 5:
		{
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x,y+10);
		}
		break;

		case 6:
		{
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+5,y+10);
		}
		break;
		
		case 7:
		{
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+10,y);
		}
		break;
	
		case 8:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x,y+10);
		Draw_realbox1(x+5,y+10);
		}
		break;
		
		case 9:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+10,y);
		}
		break;
		
		case 10:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+5,y+10);
		}
		break;
		
		case 11:
		{
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+10,y+5);
		Draw_realbox1(x+10,y);
		}
		break;
		
		case 12:
		{
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+5,y+10);
		Draw_realbox1(x,y+10);
		}
		break;
		
		case 13:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+10,y);
		Draw_realbox1(x+10,y+5);
		}
		break;
		
		case 14:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x,y+10);
		}
		break;
		
		case 15:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+10,y+5);
		}
		break;
		
		
		case 16:
		{
		Draw_realbox1(x+5,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x,y+10);
		}
		break;
		
		case 17:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+10,y+5);
		}
		break;
		
		case 18:
		{
		Draw_realbox1(x,y);
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+5,y+10);
		}
		break;
		
		case 19:
		{
		Draw_realbox1(x,y+5);
		Draw_realbox1(x+5,y+5);
		Draw_realbox1(x+5,y);
		Draw_realbox1(x+10,y);
		}
		break;
	
	
	
	
	}

}



/*************************************************
������ Deal_tuxing
���ܣ�
��ڲ�����xy����
����ֵ����
*************************************************/
void Deal_tuxing(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		}
		break;
		
		case 2:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x+20,y);
		Deal_realbox(x+30,y);
		}
		break;
		
		case 3:
		{
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x,y+20);
		Deal_realbox(x,y+30);
		}
		break;
		
		case 4:
		{
		Deal_realbox(x+10,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+20,y+10);
		}
		break;
		
		case 5:
		{
		Deal_realbox(x+10,y+10);
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x,y+20);
		}
		break;

		case 6:
		{
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+10,y+20);
		}
		break;
		
		case 7:
		{
		Deal_realbox(x+10,y+10);
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x+20,y);
		}
		break;
	
		case 8:
		{
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x,y+20);
		Deal_realbox(x+10,y+20);
		}
		break;
		
		case 9:
		{
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y);
		Deal_realbox(x+20,y);
		}
		break;
		
		case 10:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+10,y+20);
		}
		break;
		
		case 11:
		{
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+20,y+10);
		Deal_realbox(x+20,y);
		}
		break;
		
		case 12:
		{
		Deal_realbox(x+10,y);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+10,y+20);
		Deal_realbox(x,y+20);
		}
		break;
		
		case 13:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x+20,y);
		Deal_realbox(x+20,y+10);
		}
		break;
		
		case 14:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x,y+20);
		}
		break;
		
		case 15:
		{
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+20,y+10);
		}
		break;
		
		
		case 16:
		{
		Deal_realbox(x+10,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x,y+20);
		}
		break;
		
		case 17:
		{
		Deal_realbox(x,y);
		Deal_realbox(x+10,y);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+20,y+10);
		}
		break;
		
		case 18:
		{
		Deal_realbox(x,y);
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+10,y+20);
		}
		break;
		
		case 19:
		{
		Deal_realbox(x,y+10);
		Deal_realbox(x+10,y+10);
		Deal_realbox(x+10,y);
		Deal_realbox(x+20,y);
		}
		break;
	
	
	
	
	}

}


void Deal_tuxing1(u16 x,u16 y,u8 what)
{
	switch (what)
	{
		case 1:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		}
		break;
		
		case 2:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+10,y);
		Deal_realbox1(x+15,y);
		}
		break;
		
		case 3:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x,y+10);
		Deal_realbox1(x,y+15);
		}
		break;
		
		case 4:
		{
		Deal_realbox1(x+5,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+10,y+5);
		}
		break;
		
		case 5:
		{
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x,y+10);
		}
		break;

		case 6:
		{
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+5,y+10);
		}
		break;
		
		case 7:
		{
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+10,y);
		}
		break;
	
		case 8:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x,y+10);
		Deal_realbox1(x+5,y+10);
		}
		break;
		
		case 9:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+10,y);
		}
		break;
		
		case 10:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+5,y+10);
		}
		break;
		
		case 11:
		{
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+10,y+5);
		Deal_realbox1(x+10,y);
		}
		break;
		
		case 12:
		{
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+5,y+10);
		Deal_realbox1(x,y+10);
		}
		break;
		
		case 13:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+10,y);
		Deal_realbox1(x+10,y+5);
		}
		break;
		
		case 14:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x,y+10);
		}
		break;
		
		case 15:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+10,y+5);
		}
		break;
		
		
		case 16:
		{
		Deal_realbox1(x+5,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x,y+10);
		}
		break;
		
		case 17:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+10,y+5);
		}
		break;
		
		case 18:
		{
		Deal_realbox1(x,y);
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+5,y+10);
		}
		break;
		
		case 19:
		{
		Deal_realbox1(x,y+5);
		Deal_realbox1(x+5,y+5);
		Deal_realbox1(x+5,y);
		Deal_realbox1(x+10,y);
		}
		break;
	
	
	
	
	}

}





/*************************************************
������ Down_mov
���ܣ�
��ڲ�����xy����
����ֵ����
*************************************************/


void Down_tuxing_move(u16 x,u16 y,u8 what)
{
	Deal_tuxing(x,y,what);
	Draw_tuxing(x,y+10,what);
}

/*************************************************
������ Left_mov
���ܣ�
��ڲ�����xy����
����ֵ����
*************************************************/


void Left_tuxing_move(u16 x,u16 y,u8 what)
{
	Deal_tuxing(x,y,what);
	Draw_tuxing(x-10,y,what);
}

/*************************************************
������ Right_mov
���ܣ�
��ڲ�����xy����
����ֵ����
*************************************************/

void Right_tuxing_move(u16 x,u16 y,u8 what)
{
	Deal_tuxing(x,y,what);
	Draw_tuxing(x+10,y,what);
}



  









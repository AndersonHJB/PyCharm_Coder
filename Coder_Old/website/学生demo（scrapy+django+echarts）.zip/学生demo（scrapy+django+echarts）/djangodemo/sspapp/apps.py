from django.apps import AppConfig


class SspappConfig(AppConfig):
    name = 'sspapp'
